import os, sys

terminal_command = f"sudo ./arduino-cli upload -p /dev/ttyACM0 --fqbn arduino:avr:uno Blink/"
os.system(terminal_command)
